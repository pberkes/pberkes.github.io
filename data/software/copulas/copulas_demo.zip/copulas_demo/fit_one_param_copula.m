function [theta, test_ll, train_ll] = fit_one_param_copula(cdffun, all_u, all_um1, ...
                                                  all_test_u, all_test_um1, ...
                                                  lft, rgt)
  % fit_one_param_copula(cdffun, all_u, all_um1, all_test_u,
  %                      all_test_um1, lft, rgt, whichneurons)
  %
  % cdffun -- distribution function of the copula family, it's called as
  %           cdffun(u, theta)
  % all_u, all_um1 -- training data transformed through the cdf of the
  %                   marginals: all_u is F(y), all_um1 is F(y-1);
  %                   neurons are on columns, measurements on rows
  % all_test_u, all_test_um1 -- same for test data
  % lft, rgt -- bounds of the parameter of the copula family (theta)
  
  nneurons = size(all_u, 2);
  theta = zeros(nneurons);
  test_ll = zeros(nneurons);
  train_ll = zeros(nneurons);

  options = optimset('Display','off','TolCon',10^-12,'TolFun',10^-4,'TolX',10^-6);
  
  for ii = 1:nneurons
    for jj = ii+1:nneurons
      %fprintf('----------------- %d vs %d\n', ii, jj);
      u = all_u(:,[ii,jj]);
      um1 = all_um1(:,[ii,jj]);
      [theta_est ll] = fminbnd(@(theta)bivariate_obj(u, um1, cdffun, theta), ...
                               lft, rgt, options);
      theta(ii,jj) = theta_est;
      train_ll(ii,jj) = -ll;

      % test log likelihood
      if nargout>1
        %fprintf('- test ---------- %d vs %d\n', ii, jj);
        test_u = all_test_u(:,[ii,jj]);
        test_um1 = all_test_um1(:,[ii,jj]);
        test_ll(ii,jj) = - bivariate_obj(test_u, test_um1, cdffun, ...
                                         theta(ii,jj));
      end
    end
  end

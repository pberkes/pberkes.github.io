function ll = gauss_objfun(rho, phiinv_u, phiinv_um1)
  pmf = gauss_pmf(rho,phiinv_u,phiinv_um1);
  ll = -sum(log(max(pmf, realmin('double'))));

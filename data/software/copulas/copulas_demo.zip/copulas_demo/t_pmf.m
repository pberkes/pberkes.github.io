function pmf = t_pmf(rho, df, u, um1)
  
  C = [1 rho; rho 1];
  tinv_u = tinv(u, df);
  tinv_um1 = tinv(um1, df);
  
  % rarely there are rounding errors
  err_idx = tinv_u-tinv_um1<0;
  tinv_um1(err_idx) = tinv_u(err_idx);

  pmf = mvtcdf(tinv_um1, tinv_u, C, df);

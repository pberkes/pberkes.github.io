function plot_copula_pdf(pdffun, varargin)
  
  % %% default settings
  ctxt.title = '';
  ctxt.xlbl_str = 'u_1';
  ctxt.ylbl_str = 'u_2';
  ctxt.npoints = 100;
  ctxt.fontsize = 20;
  ctxt.fname = '';
  ctxt.imgpath = '';
  ctxt.log = 0;
  ctxt.max_z = 10;
  ctxt.cmap = 'jet';
  
  % %% overwrite with user-defined list of settings
  for k = 1:2:length(varargin);
    if ~ischar(varargin{k}),
      error 'Setting names must be strings';
    end
 
    % set variable value
    ctxt = setfield(ctxt,varargin{k},varargin{k+1});
  end

  [x1,x2] = meshgrid(linspace(0.01,0.99,ctxt.npoints));
  z = pdffun([x1(:) x2(:)]);
  z = reshape(z, ctxt.npoints, ctxt.npoints);
  
  clf
  set(gcf, 'PaperType', 'a4letter', ...
           'Position', [870   277   628   557], ...
           'PaperPosition', [1.37768 3.40189 5.51235 4.88914]);
  colormap(ctxt.cmap);

  if ctxt.log,
    log_z = max(log(z),-4);
    surface(x1,x2,log_z, 'EdgeColor', 'none');
  else
    z = min(z,ctxt.max_z);
    surface(x1,x2,z, 'EdgeColor', 'none');
  end
  set(gca, 'XLim', [0.01, 0.99], 'YLim', [0.01, 0.99], ...
           'XTick', [0.01, 0.5, 0.99], 'YTick', [0.01, 0.5, 0.99], ...
           'XTickLabel', [0,0.5,1], 'YTickLabel', [0,0.5,1], ...
           'FontSize', ctxt.fontsize, ...
           'PlotBoxAspectRatio', [1,1,1]);
  xlabel(ctxt.xlbl_str, 'FontSize', ctxt.fontsize)
  ylabel(ctxt.ylbl_str, 'FontSize', ctxt.fontsize);
  title(ctxt.title,'FontSize',ctxt.fontsize);

  if ~strcmp(ctxt.fname, '')
    path = ctxt.imgpath;
    disp(['save' path ctxt.fname])
    saveas(gcf, [path ctxt.fname '.fig'], 'fig');
    saveas(gcf, [path ctxt.fname '.eps'], 'eps2c');
    saveas(gcf, [path ctxt.fname '.png'], 'png');
  end
  
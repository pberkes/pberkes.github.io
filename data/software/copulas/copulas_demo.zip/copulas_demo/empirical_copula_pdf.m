function [copula_pdf, significance, cdf1, cdf2] = empirical_copula_pdf(x1, x2, varargin)
% function [copula_pdf, cdf1, cdf2] = empirical_copula_pdf(x1, x2, [nbootstrap=10000])
%  assumes that x1, x2 are count variables (i.e., integers starting at 0)
  
  % %%% optional arguments
  nbootstrap = 10000;
  if nargin==3
    nbootstrap = varargin{1};
  end
  
  tlen = size(x1, 1);
  
  % %%%
  % get empirical cdf/pdf for the single variables
  [pdf1, cdf1] = empirical_pdf(x1);
  [pdf2, cdf2] = empirical_pdf(x2);

  % %% compute empirical joint distribution in the copula space
  % data in the copula space
  cdf1_timeseries = cdf1(x1+1);
  cdf2_timeseries = cdf2(x2+1);
  % empirical joint
  copula_hist = hist2d([cdf1_timeseries, cdf2_timeseries], ...
                       [0; cdf1]+1e-7, [0; cdf2]+1e-7);
  copula_pdf =  copula_hist./tlen;
  % normalize by area (1.0 is uniform)
  warning('off', 'MATLAB:divideByZero');
  copula_pdf = copula_pdf./(pdf1*pdf2');
  copula_pdf(isnan(copula_pdf)) = 0;
  warning('on', 'MATLAB:divideByZero');

  % test: int(copula_pdf(x1,x2), x1) should be uniform
  % sum(copula_pdf.*repmat(pdf1, 1, size(pdf2,1))) should give all 1.0

  % %% significance by bootstrap
  % make second neuron independent from the first by shuffling the data
  [p, q] = size(copula_pdf);
  bootstrap_hist = zeros(nbootstrap, p, q);
  bootstrap_pdf = zeros(nbootstrap, p, q);
  warning('off', 'MATLAB:divideByZero');
  for n = 1:nbootstrap
    % sample from the empirical distribution for the first neuron
    % (get random indices)
    si = ceil(tlen.*rand(tlen,1));
    cdf1_shuffle = cdf1_timeseries(si);
    % sample from the empirical distribution for the second neuron
    % (get random indices)
    si = ceil(tlen.*rand(tlen,1));
    cdf2_shuffle = cdf2_timeseries(si);
    % empirical bootstrapped joint
    shuffled_hist = hist2d([cdf1_shuffle, cdf2_shuffle],...
                           [0; cdf1]+1e-7, [0; cdf2]+1e-7);
    shuffled_pdf = shuffled_hist / size(cdf1_shuffle, 1);
    % normalize by area (1.0 is uniform)
    shuffled_pdf = shuffled_pdf./(pdf1*pdf2');
    % record
    bootstrap_hist(n,:,:) = shuffled_hist;
    bootstrap_pdf(n,:,:) = shuffled_pdf;
  end
  warning('on', 'MATLAB:divideByZero');

  % significance legend:
  % positive: null hypothesis = data count not larger than independent
  % with same marginals
  % negative: null hypothesis = data count not smaller than independent
  % with same marginals
  % sign. levels: 3 = p<0.001, 2 = p<0.01, 1 = p<0.05, 0 = p>=0.05

  significance = zeros(p, q); % significantly larger/smaller than independent
  for i = 1:p
    for j = 1:q
      perc = sum(copula_hist(i,j) > bootstrap_hist(:,i,j))/nbootstrap;
      if perc>0.999, significance(i,j) = 3;
      elseif perc>0.99, significance(i,j) = 2;
      elseif perc>0.95, significance(i,j) = 1;
      end
      perc = sum(copula_hist(i,j) < bootstrap_hist(:,i,j))/nbootstrap;
      if perc>0.999, significance(i,j) = -3;
      elseif perc>0.99, significance(i,j) = -2;
      elseif perc>0.95, significance(i,j) = -1;
      end
    end
  end


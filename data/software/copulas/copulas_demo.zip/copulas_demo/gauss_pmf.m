function pmf = gauss_pmf(rho, phiinv_u, phiinv_um1)
  opts = statset('TolFun', 1e-8);
  pmf = mvncdf(phiinv_um1, phiinv_u, zeros(1,2), [1 rho; rho 1], opts);

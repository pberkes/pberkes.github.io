% demo: fitting copulas and selecting the best fitting with cross-validation
% author: Pietro Berkes, berkes@brandeis.edu

%% create some artificial data using a Clayton copula

disp('Start demo');

% paramter of the copula
theta = 2.4;
% parameters of the Poisson marginals
lbd0 = [4,6];
% sample size for training and test set
n_train = 200;
n_test = 100;

% generate points from copula
u0_train = copularnd('Clayton', theta, n_train);
u0_test = copularnd('Clayton', theta, n_test);
% get Poisson marginals
frate_train = poissinv(u0_train, repmat(lbd0,n_train,1));
frate_test = poissinv(u0_test, repmat(lbd0,n_test,1));



%% fit copulas to data

% fit poisson parameters
lbd = mean(frate_train, 1);

% u and u- (Eq. 6 in the NIPS paper) are pre-calculated to speed things up
% transform firing rate using poisson cdf
all_u = poisscdf(frate_train, repmat(lbd,n_train,1));
all_um1 = poisscdf(frate_train-1, repmat(lbd,n_train,1));

% same for test data
all_test_u = poisscdf(frate_test, repmat(lbd,n_test,1));
all_test_um1 = poisscdf(frate_test-1, repmat(lbd,n_test,1));



% now consider many different copula families, fit parameters on train
% data, then compute log likelihood on test data

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% independent copula

% the reason why all the test_ll variables are 2x2, and only the (1,2)
% element is filles is that the original code is made to handle multiple
% neurons, and fills the upper right side of a NxN matrix with all the
% pairwise comparisons
independent_test_ll = zeros(2, 2);
indep_cdffun = @(u, params) u(:,1).*u(:,2);
independent_test_ll(1,2) = - bivariate_obj(all_test_u, all_test_um1, indep_cdffun,[]);
fprintf('%.2f independent Poisson neurons test llhood\n', independent_test_ll(1,2));


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Clayton and associated copulas

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Clayton copula
clayton_cdffun = @(u, theta)(copulacdf('Clayton', u, theta));
[clayton_theta, clayton_test_ll] = ...
    fit_one_param_copula(clayton_cdffun, all_u, all_um1, ...
                         all_test_u, all_test_um1, 0, 10);
fprintf('%.2f Clayton test llhood\n', clayton_test_ll(1,2));

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Clayton copula for negative dependencies
clayton_neg_cdffun = @(u, theta) max((sum(u.^(-theta), 2) -1), 0).^(-1/theta);
[clayton_neg_theta, clayton_neg_test_ll] = ...
    fit_one_param_copula(clayton_neg_cdffun, all_u, all_um1, ...
                         all_test_u, all_test_um1, -1, 0);
fprintf('%.2f negative Clayton test llhood\n', clayton_neg_test_ll(1,2));

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Clayton copula for upper-lower dependencies
clayton_ul_cdffun = @(u, theta)(u(:,2) - copulacdf('Clayton', [1-u(:,1) u(:,2)], theta));
[clayton_ul_theta, clayton_ul_test_ll] = ...
    fit_one_param_copula(clayton_ul_cdffun, all_u, all_um1, ...
                         all_test_u, all_test_um1, 0, 10);
fprintf('%.2f UL Clayton test llhood\n', clayton_ul_test_ll(1,2));

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Clayton copula for lower-upper dependencies
clayton_lu_cdffun = @(u, theta)(u(:,1) - copulacdf('Clayton', [u(:,1) 1-u(:,2)], theta));
[clayton_lu_theta, clayton_lu_test_ll] = ...
    fit_one_param_copula(clayton_lu_cdffun, all_u, all_um1, ...
                         all_test_u, all_test_um1, 0, 10);
fprintf('%.2f LU Clayton test llhood\n', clayton_lu_test_ll(1,2));

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Clayton copula for upper-upper dependencies
clayton_uu_cdffun = @(u, theta)(sum(u,2) - 1 + copulacdf('Clayton', 1-u, theta));
[clayton_uu_theta, clayton_uu_test_ll] = ...
    fit_one_param_copula(clayton_uu_cdffun, all_u, all_um1, ...
                         all_test_u, all_test_um1, 0, 10);
fprintf('%.2f UU Clayton test llhood\n', clayton_uu_test_ll(1,2));


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gumbel copula

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Gumbel copula
gumbel_cdffun = @(u, theta)(copulacdf('Gumbel', u, theta));
[gumbel_theta, gumbel_test_ll] = ...
    fit_one_param_copula(gumbel_cdffun, all_u, all_um1, ...
                         all_test_u, all_test_um1, 1, 20);
fprintf('%.2f Gumbel test llhood\n', gumbel_test_ll(1,2));

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Frank

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Frank copula
frank_cdffun = @(u, theta)(copulacdf('Frank', u, theta));
[frank_theta, frank_test_ll] = ...
    fit_one_param_copula(frank_cdffun, all_u, all_um1, ...
                         all_test_u, all_test_um1, -10, 10);
fprintf('%.2f Frank test llhood\n', frank_test_ll(1,2));


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gaussian and Student-t copulas require some extra code

% optimization function settings
options = optimset('Display','off','TolCon',10^-12,'TolFun',10^-2,'TolX',10^-4);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Gaussian copula
disp('Fitting Gaussian copulas, please wait...');
gauss_rho = zeros(2, 2);

% equalize with gaussian marginals
phiinv_u = norminv(all_u);
phiinv_um1 = norminv(all_um1);
    
% WARNING: for the paper I used 1e-8 but then it's *slow*
opts = statset('TolFun', 1e-4); 
gauss_pmf_helper = @(rho)mvncdf(phiinv_um1, phiinv_u, zeros(1,2), [1 rho; rho 1], opts);
gauss_objfun_helper = @(rho)(-sum(log(max(gauss_pmf_helper(rho), realmin('double')))));
[rho_est ll] = fminbnd(gauss_objfun_helper, -1, 1,options);

gauss_rho(1,2) = rho_est;

% compute log likelihood on test data
gauss_test_ll = zeros(2,2);

phiinv_u = norminv(all_test_u);
phiinv_um1 = norminv(all_test_um1);
    
gauss_test_ll(1,2) = - gauss_objfun(gauss_rho(1,2),phiinv_u,phiinv_um1);
fprintf('%.2f Gaussian test llhood\n', gauss_test_ll(1,2));

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit Student-t copula (two parameters)
disp('Fitting Student-t copulas, please wait...');
t_rho_nv = zeros(2, 2, 2);

params0 = [0.5, 1.0];

% WARNING: for the paper I used 1e-8 but then it's *slow*
opts = statset('TolFun', 1e-4);
t_pmffun = @(params)t_pmf(params(1), params(2), all_u, all_um1);
t_objfun = @(params)(-sum(log(max(t_pmffun(params), realmin('double')))));
lower = [-0.99, 1.0];
upper = [0.99, Inf];
warning('off', 'optim:fmincon:SwitchingToMediumScale');
[params_est ll] = fmincon(t_objfun, params0, [],[],[],[],lower,upper,[],options);
warning('on', 'optim:fmincon:SwitchingToMediumScale');

t_rho_nv(1,2,:) = params_est;

% %%%
% compute log likelihood on test data

t_test_ll = zeros(2);
t_pmffun = @(params,u,um1)t_pmf(params(1), params(2), u, um1);
t_objfun = @(params,u,um1)(-sum(log(max(t_pmffun(params,u,um1), realmin('double')))));

t_test_ll(1,2) = - t_objfun(t_rho_nv(1,2,:),all_test_u,all_test_um1);
fprintf('%.2f Student-t test llhood\n', t_test_ll(1,2));

%% prints and plots
disp('If everything went according to plan, the log likelihoog of the Clayton copula should be highest!');


% plot empirical copula of training data
disp('Fig 1: empirical copula (cf. Fig 5 NIPS paper)');
[copula_pdf, significance, cdf1, cdf2] = ...
    empirical_copula_pdf(frate_train(:,1), frate_train(:,2), 1000);

figure(1);
clf();
plot_poisson_copula(cdf1, cdf2, copula_pdf, false, false, 3);
set(gca, 'FontSize', 20);
colorbar;
set(gca, 'FontSize', 20);

title('Empirical copula');
xlabel('u_1');
ylabel('u_2');

% plot pdf of fitted Clayton copula
disp('Fig 2: fitted copula (cf. Fig 5 NIPS paper)');
figure(2);
plot_copula_pdf(@(u)copulapdf('Clayton', u, clayton_theta(1,2)));
set(gca, 'FontSize', 20);
title('Fitted copula');
xlabel('u_1');
ylabel('u_2');

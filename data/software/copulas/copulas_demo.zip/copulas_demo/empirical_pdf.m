function [pdf, cdf] = emprirical_pdf(rate, varargin)
% function [pdf, cdf] = emprirical_cdf(rate, [max_rate])
%
%  Returns the empirical probability density function (pdf) and the
%  empirical cumulative distribution function (cdf) for the count
%  timeseries 'rate'

  max_rate = max(rate);
  if nargin==2
    max_rate = varargin{1};
  end

  edges = [0:max_rate];
  n = histc(rate, edges);
  pdf = n/sum(n);
  cdf = cumsum(n)/sum(n);

function hdl = plot_poisson_copula(cdf1, cdf2, copula_pdf, varargin)
% function plot_poisson_copula(cdf1, cdf2, copula_pdf, [is_significance=false, is_log=false])
%
%  plots the empirical joint distribution of the to neurons with indices
%  idx1 and idx2
  
  % optional arguments
  is_significance = 0;
  is_log = 0;
  upper_lim = 2;
  if nargin>3, is_significance = varargin{1}; end
  if nargin>4, is_log = varargin{2}; end
  if nargin>5, upper_lim = varargin{3}; end

  % in pcolor, the last column and row of the matrix is ignored; we need to
  % add additional zeros at the end of copula_pdf
  [ucdf1, uidx1] = unique(cdf1);
  [ucdf2, uidx2] = unique(cdf2);
  [xs,ys] = meshgrid([0; ucdf1], [0; ucdf2]);

  im = zeros(length(uidx1)+1,length(uidx2)+1);
  im(1:end-1, 1:end-1) = copula_pdf(uidx1,uidx2);
  if is_log, im(1:end-1, 1:end-1) = log(copula_pdf(uidx1,uidx2)); end

  clf
  
  hdl = pcolor(xs', ys', im);
  axis image

  if is_significance
    colormap([[0.0,0.0,1.0];[0.0,0.5,1.0];[0.0,1.0,1.0]; ...
              [0.5,0.5,0.5];[1.0,1.0,0.0];[1.0,0.5,0.0];[1.0,0.0,0.0]])
    set(gca, 'CLim', [-3,3]);
  else
    colormap(jet(64))
    if is_log
        set(gca,'CLim',[log(1/upper_lim), log(upper_lim)]);
    else
        set(gca,'CLim',[0,upper_lim]);
    end
  end

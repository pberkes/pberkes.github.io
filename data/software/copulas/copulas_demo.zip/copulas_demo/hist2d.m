function mHist = hist2d (mX, vYEdge, vXEdge)
%function mHist = hist2d ([vY, vX], vYEdge, vXEdge)
%2 Dimensional Histogram
%Counts number of points in the bins defined by vYEdge, vXEdge.
%size(vX) == size(vY) == [n,1]
%size(mHist) == [length(vYEdge) -1, length(vXEdge) -1]
%
%EXAMPLE
%   mYX = rand(100,2);
%   vXEdge = linspace(0,1,10);
%   vYEdge = linspace(0,1,20);
%   mHist2d = hist2d(mYX,vYEdge,vXEdge);
%
%   nXBins = length(vXEdge);
%   nYBins = length(vYEdge);
%   vXLabel = 0.5*(vXEdge(1:(nXBins-1))+vXEdge(2:nXBins));
%   vYLabel = 0.5*(vYEdge(1:(nYBins-1))+vYEdge(2:nYBins));
%   pcolor(vXLabel, vYLabel,mHist2d); colorbar

% code by Kangwon Lee, downloaded from Mathworks
  
nCol = size(mX, 2);
if nCol < 2
    error ('mX has less than two columns')
end

nRow = length (vYEdge)-1;
nCol = length (vXEdge)-1;

vRow = mX(:,1);
vCol = mX(:,2);

mHist = zeros(nRow,nCol);

for iRow = 1:nRow
    rRowLB = vYEdge(iRow);
    rRowUB = vYEdge(iRow+1);
    
    vColFound = vCol((vRow > rRowLB) & (vRow <= rRowUB));
    
    if (~isempty(vColFound))
        
        
        vFound = histc (vColFound, vXEdge);
        
        nFound = (length(vFound)-1);
        
        if (nFound ~= nCol)
            disp([nFound nCol])
            error ('hist2d error: Size Error')
        end
        
        [nRowFound, nColFound] = size (vFound);
        
        nRowFound = nRowFound - 1;
        nColFound = nColFound - 1;
        
        if nRowFound == nCol
            mHist(iRow, :)= vFound(1:nFound)';
        elseif nColFound == nCol
            mHist(iRow, :)= vFound(1:nFound);
        else
            error ('hist2d error: Size Error')
        end
    end
    
end

% $$$ my code, probably slower
% $$$ function h = hist2d(x,y, xbins, ybins)
% $$$ % function h = hist2d(x,y, xbins, ybins)
% $$$ %
% $$$ %  Simple function to compute a 2D histogram. There must be a better way
% $$$ %  that uses histc.
% $$$ %
% $$$ %  x, y are the two [NxD] variables to be histogrammed (N is the number
% $$$ %  of data points, D the dimensionality). xbins and ybins are the
% $$$ %  starting points of the bins.
% $$$ %  
% $$$ %  returns h(i,j) = number of point in the box
% $$$ %  [xbins(j), xbins(j+1)) x [ybins(i), ybins(i+1)). Points not belonging
% $$$ %  to any box are discarded
% $$$   
% $$$   nxbins = length(xbins);
% $$$   nybins = length(ybins);
% $$$   h = zeros(nybins-1, nxbins-1);
% $$$   for i=1:nybins-1,
% $$$     idx_y = find(y>=ybins(i) & y<ybins(i+1));
% $$$     tmp = x(idx_y);
% $$$     for j=1:nxbins-1,
% $$$       h(i,j) = sum(tmp>=xbins(j) & tmp<xbins(j+1));
% $$$     end
% $$$   end

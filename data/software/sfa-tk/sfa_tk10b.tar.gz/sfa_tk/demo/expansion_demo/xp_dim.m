function dim = xp_dim( input_dim ),
% Alternative xp_dim function, used by the demo script
% sfa_tk/demo/expansion_demo.m
  
  fprintf('******* sfa-tk is using a user-defined XP_DIM function!\n');
  dim = 2*input_dim;

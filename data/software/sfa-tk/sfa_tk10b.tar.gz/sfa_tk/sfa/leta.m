function res=leta(DATA,T)
% LETA Compute the eta values of long data signals.
%   ETAVAL = LETA(DATA, T) updates the internal structures and returns
%   the eta values of the data signals seen so far.
%   Important: the DATA signal must be normalized
%              (zero mean and unit variance)
%
%   LETA without arguments clears the global structures.
%
%   example:    
%   % clear the global structure
%   leta
%   % first data chunck
%   leta(DATA1,1)
%   % ...
%   % last data chunck
%   eta_values = leta(DATAN,1)
%
%   See also ETA

  if nargin==0,
    clear global LETA_VAR LETA_DIFF LETA_TLEN
    return
  end

  global LETA_VAR LETA_DIFF LETA_TLEN
  
  if isempty(LETA_VAR),
    LETA_VAR=zeros(1,size(DATA,2));
    LETA_DIFF=zeros(1,size(DATA,2));
    LETA_TLEN=0;
  end
  
  LETA_VAR=LETA_VAR+sum(DATA.^2);
  LETA_DIFF=LETA_DIFF+sum(timediff(DATA).^2);
  LETA_TLEN=LETA_TLEN+size(DATA,1);
  
  if LETA_VAR==0, res=Inf; return, end
  res=sqrt(LETA_DIFF./(LETA_VAR/(LETA_TLEN-1))/LETA_TLEN)*T/(2*pi);
